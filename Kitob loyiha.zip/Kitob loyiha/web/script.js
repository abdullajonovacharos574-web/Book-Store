// ================== ADD TO CART ==================
const addToCartBtn = document.querySelector('.add-to-cart');

if (addToCartBtn) {
    addToCartBtn.addEventListener('click', () => {

        const book = {
            title: 'Little Prince',
            author: 'Antoine de Saint-Exupéry',
            price: 700,
            image: './img/Little prince book cover.png'
        };

        // Eski savatni olamiz
        let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

        // Kitobni qo‘shamiz
        cart.push(book);

        // Qayta saqlaymiz
        sessionStorage.setItem('cart', JSON.stringify(cart));

        // Savat sahifasiga o‘tamiz
        window.location.href = './cart.html';
    });
}

// ================== LOAD CART ==================
const result = document.querySelector('.result');

if (result) {
    const cart = JSON.parse(sessionStorage.getItem('cart')) || [];

    result.innerHTML = '';

    cart.forEach(book => {
        result.innerHTML += `
            <div class="book-sale">
                <img width="145px" src="${book.image}" alt="">

                <div class="book-sale-p">
                    <b>${book.title}</b><br>
                    ${book.author}
                    <p class="narx">Rs. ${book.price}/=</p>
                </div>

                <form>
                    <label>Copies</label>
                    <input type="number" value="1" min="1">
                </form>
            </div>
        `;
    });
}